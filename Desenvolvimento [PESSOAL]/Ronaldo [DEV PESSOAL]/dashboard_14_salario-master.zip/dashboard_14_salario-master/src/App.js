
import './App.css';
import AppRoutes from './routes.js'

function App() {
  return (
    <div className="App">
      <AppRoutes/>
    </div>
  );
}

export default App;
