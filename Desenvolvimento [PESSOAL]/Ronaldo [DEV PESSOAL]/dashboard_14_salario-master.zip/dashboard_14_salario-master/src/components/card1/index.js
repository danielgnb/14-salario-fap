import './card1.css'

const Card1 = () => {
    return ( 
    <section>
        <div className='card1-container'>
            <div className='card1-titulo-container'>% de Funcionário Abaixo da Média</div>
            <div className='card1-conteudo-container'>25,3%</div>
        </div>

    </section>
    )
}

export default Card1