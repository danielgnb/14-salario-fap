import './card.css'

const Card = () => {
    return ( 
    <section>
        <div className='card-container'>
            <div className='card-titulo-container'>Média das Notas desse Ano</div>
            <div className='card-conteudo-container'>592,55</div>
        </div>

    </section>
    )
}

export default Card