import './cnthome.css'

const Cnthome = () => {
    return ( 
    <section>
        <div className='cnt-container'>
            <p>Bem-vindo ao Painel de Controle do Desempenho dos Funcionário!<p/> É aqui que esforços excepcionais 
                encontram oportunidades gratificantes. Como parte do compromisso da nossa empresa de reconhecer 
                e valorizar o trabalho árduo dos nosssos colaboradoress, este painel permite-lhe adicionar as notas de desempenho e acompanhar o progresso.</p>
            <p>Lembre-se de que seu sucesso alimenta nosso sucesso coletivo. Obrigado por ser uma parte inestimável de nossa equipe e estamos ansiosos para comemorar suas conquistas juntos.</p>
        </div>

    </section>
    )
}

export default Cnthome