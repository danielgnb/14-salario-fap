import './card3.css'

const Card3 = () => {
    return ( 
    <section>
        <div className='card3-container'>
            <div className='card3-titulo-container'>Quantidade de Avaliações desse Ano</div>
            <div className='card3-conteudo-container'>255</div>
        </div>

    </section>
    )
}

export default Card3