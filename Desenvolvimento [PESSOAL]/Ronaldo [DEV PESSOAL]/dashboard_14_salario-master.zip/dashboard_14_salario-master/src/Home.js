import './App.css';
import Navbar from './components/navbar';
import Sectionlogin from './components/sectionlogin';


function Home() {
  return (
    <div className="App">
     <Navbar />
      <Sectionlogin/>

    </div>
  );
}

export default Home;