import './App.css';

import Content3 from './components/content3';
import Menu from './components/menu';
import Navbar from './components/navbar';




function Lista() {
  return (
    <div className="App">
     <Navbar />
     <Menu/>
     <Content3/>

    </div>
  );
}

export default Lista;